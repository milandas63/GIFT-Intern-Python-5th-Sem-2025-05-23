from django.shortcuts import render
from django.http import HttpResponse

# def home(request):
#     return HttpResponse("<h1 style='color:red;text-align:center;background-color:lightGray;'>Hello World</h1>")

def index(request):
    return render(request, "index.html")
